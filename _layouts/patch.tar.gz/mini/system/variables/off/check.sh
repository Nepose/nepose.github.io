#!/bin/bash
# method stub
# Please read instructions in the readme.md file
